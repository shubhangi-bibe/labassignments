package com.capgemini.lab10.assignments;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;



public class Exercise2Tester {

	  public static void main(String rr[])throws IOException
      {
             Exercise2 e=new Exercise2();
             BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
             System.out.println("Enter file name");
             String s=br.readLine();
             e.analyze(s);
      }
}

