package com.capgemini.lab4.assignment.no3;

public class JournalPaper extends WrittenItem
{
	private int year;
	
	public JournalPaper(int idNumber, String title, int numOfCopies, String author, int year) {
		super(idNumber, title, numOfCopies, author);
		this.year = year;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}
	
	@Override
	public void print() 
	{
		super.print();
		System.out.println("Year: " + year);
	}

}
