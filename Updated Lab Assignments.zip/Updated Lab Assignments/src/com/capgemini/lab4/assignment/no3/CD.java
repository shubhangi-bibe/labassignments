package com.capgemini.lab4.assignment.no3;

public class CD extends MediaItem
{
	private String artist, CDgenre;
	
	public CD(int idNumber, String title, int numOfCopies, int runtime, String artist, String CDgenre) {
		super(idNumber, title, numOfCopies, runtime);
		this.artist = artist;
		this.CDgenre = CDgenre;
	}

	public String getArtist() {
		return artist;
	}

	public void setArtist(String artist) {
		this.artist = artist;
	}

	public String getCDgenre() {
		return CDgenre;
	}

	public void setCDgenre(String cDgenre) {
		CDgenre = cDgenre;
	}
	
	@Override
	public void print() 
	{
		super.print();
		System.out.println("Artist: " + artist);
		System.out.println("Genre: " + CDgenre);
	}
}
