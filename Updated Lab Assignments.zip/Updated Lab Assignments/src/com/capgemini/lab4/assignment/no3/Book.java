package com.capgemini.lab4.assignment.no3;

public class Book extends WrittenItem
{
	public Book(int idNumber, String title, int numOfCopies, String author) {
		super(idNumber, title, numOfCopies, author);
	}
}
