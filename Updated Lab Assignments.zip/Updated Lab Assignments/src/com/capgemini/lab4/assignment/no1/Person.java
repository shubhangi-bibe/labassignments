package com.capgemini.lab4.assignment.no1;
public class Person{
private float age;
private String name;

public Person(float age, String name) {
	super();
	this.age = age;
	this.setName(name);
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public float getAge() {
	return age;
}


}
