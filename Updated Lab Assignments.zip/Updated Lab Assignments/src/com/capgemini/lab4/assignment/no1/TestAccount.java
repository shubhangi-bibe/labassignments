package com.capgemini.lab4.assignment.no1;

public class TestAccount {
	public static void main(String[] args) {
		Saving s=new Saving("Smith");
		s.deposit(1000);
		s.withdraw(700);
		s.display();
		System.out.println(s.getBalance());
		Current c=new Current("Polo",2000);
		c.withdraw(1000);
		c.display();
		c.withdraw(7000);
		c.display();
		
	}
}
