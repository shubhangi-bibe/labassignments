package com.capgemini.lab4.assignment.no2;

public interface EmployeeService {
	
	public abstract void getEmployeeDetails(Employee emp);
	public abstract String findInsuranceScheme(Employee emp);
	public abstract void showEmployeeDetails(Employee emp);
	
}

