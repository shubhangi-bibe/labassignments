package com.capgemini.lab4.assignment.no2;

public enum Designation {
	SYSTEM_ASSOCIATE, MANAGER, PROGRAMMER, CRERK
}
