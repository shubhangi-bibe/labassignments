package com.capgemini.lab5.assignments;

public class NameException extends Exception {

	private String printMsg;
	
	public NameException() {
		
	}
	
	public NameException(String printMsg) {
		this.printMsg=printMsg;
	}
	
	public String getMessage() {
		return this.printMsg;
	}
}

