package com.capgemini.lab6.ssignments;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map.Entry;
import java.util.Set;

public class Exercise1 {

	public static void main(String[] args) {
		HashMap<String,Integer> bookMap = new HashMap<String, Integer>();
		bookMap.put("JAVA", 325);
		bookMap.put("HTML and CSS", 250);
		bookMap.put("C++", 200);
		bookMap.put("C-Sharp", 350);
		bookMap.put("Python",400);
		
		ArrayList<Entry<String,Integer>> bookList = new ArrayList<Entry<String,Integer>>();
		bookList = (ArrayList<Entry<String, Integer>>) sortByValue(bookMap);
		System.out.println(bookList);
		
	}

	private static List<Entry<String, Integer>> sortByValue(HashMap<String, Integer> bookMap) {
		
		Set<Entry<String, Integer>> bookSet = bookMap.entrySet();
		List<Entry<String, Integer>> arrayList = new ArrayList<Entry<String, Integer>>(bookSet);
		
		return arrayList;
	}

}
