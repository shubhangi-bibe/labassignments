package com.capgemini.lab7.assignments.exception;

public class EmployeeException extends Exception{
	private String message;
	
	public EmployeeException() {
		super();
	}

	public EmployeeException(String message) {
		super();
		this.message = message;
	}

	@Override
	public String getMessage() {
		return this.message+ "\n"+super.getMessage();
	}
	
	
}
