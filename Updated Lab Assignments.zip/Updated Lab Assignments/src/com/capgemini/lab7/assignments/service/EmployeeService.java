package com.capgemini.lab7.assignments.service;
import com.capgemini.lab7.assignments.bean.Employee;
import com.capgemini.lab7.assignments.exception.EmployeeException;

import java.util.List;

public interface EmployeeService {
	public Integer addEmployee(Employee employee) throws EmployeeException;
	public Integer deleteEmployee(Integer empid) throws EmployeeException;
	public List<Employee> 
	getEmployeesByInsuranceScheme(String insuranceScheme) 
			throws EmployeeException;
	
	public List<Employee> getAllEmployees() throws EmployeeException;
}
