package com.capgemini.lab1.assignments;



import java.util.Scanner;

public class FibonacciSequence {
	static int n1=1,n2=1,n3=0;
	static void printFibonacci(int count){    
	    if(count>0){    
	         n3 = n1 + n2; 
	         System.out.print(" "+n3);	        
	         n1 = n2;    
	         n2 = n3;    
	            
	         printFibonacci(count-1);    
	     }    
	 }    

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		int count=0;
		System.out.println("Enter the value: ");
		count=sc.nextInt();
		System.out.println("-----------without recursion----------");
		int n1=1, n2=1,n3=0;
		System.out.println(n1+"\n"+n2);
		for(int i=0;i<count;i++)
		{
			n3=n1+n2;
			System.out.println(n3);
			n1=n2;
			n2=n3;
		}
		System.out.println("-----------with recursion------------");
		printFibonacci(count-2);

	}
	

}

