package com.capgemini.lab9.lambdaExpressions;

@FunctionalInterface
public interface Exercise3 {
 
	public abstract String authenticate(String userName, String password);
}
