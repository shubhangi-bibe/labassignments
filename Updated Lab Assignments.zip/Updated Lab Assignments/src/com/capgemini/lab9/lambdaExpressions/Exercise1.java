package com.capgemini.lab9.lambdaExpressions;

@FunctionalInterface
public interface Exercise1 {

	public abstract int powerOfX(int x, int y);
}
