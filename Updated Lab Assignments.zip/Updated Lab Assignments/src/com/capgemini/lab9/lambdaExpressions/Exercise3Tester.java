package com.capgemini.lab9.lambdaExpressions;

import java.util.Scanner;

public class Exercise3Tester {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter User Name: ");
		String userName = sc.nextLine();
		System.out.println("Enter password: ");
		String password = sc.next();
		
		Exercise3 ex = (name, pass)->{if(name.equals("admin")&&pass.equals("admin@123"))
		 return "Successful";
		else 
			return "Failed";
		};

		System.out.println(ex.authenticate(userName, password));
	}

}
