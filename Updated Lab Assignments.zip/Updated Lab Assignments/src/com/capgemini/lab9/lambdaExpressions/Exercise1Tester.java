package com.capgemini.lab9.lambdaExpressions;
import java.lang.Math.*;
import java.util.Scanner;

public class Exercise1Tester {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter value for x: ");
		int a = sc.nextInt();
		System.out.println("Enter value for y: ");
		int b = sc.nextInt();
		
		  Exercise1 ex = (x,y)->(int)Math.pow(x,y);
		 System.out.println(ex.powerOfX(a, b));

	}

}
