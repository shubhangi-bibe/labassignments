package com.capgemini.lab9.lambdaExpressions;

import java.util.Scanner;

@FunctionalInterface
 interface EmployeeInterface{
	Employee1 getDetails(int id, String name);
	
}

 class Employee1{
	private int id;
	private String name;
	
	Employee1(){
		
	}

	public Employee1(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + "]";
	}
	
	
	
}
public abstract class Exercise4 implements EmployeeInterface {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter employee id and name");
		int id = sc.nextInt();
		String name = sc.nextLine();
		EmployeeInterface e = Employee1 :: new;
		System.out.println(e.getDetails(id, name));
	}

}
