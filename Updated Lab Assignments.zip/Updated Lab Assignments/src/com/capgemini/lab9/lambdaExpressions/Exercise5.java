package com.capgemini.lab9.lambdaExpressions;

import java.util.Scanner;
import java.util.function.Function;

public class Exercise5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Scanner sc = new Scanner(System.in);
      System.out.println("Enter the number: ");
      int num = sc.nextInt();
     Function<Integer,Integer> function= Exercise5::factorial;
    int fact = function.apply(num);
    System.out.println(fact);
	}
	
	public static int factorial(int num)
	{
		int fact = num;
		for(int i=1;i<num;i++)
		{
			fact = fact * i;
		}
		return fact;
	}
	
}
