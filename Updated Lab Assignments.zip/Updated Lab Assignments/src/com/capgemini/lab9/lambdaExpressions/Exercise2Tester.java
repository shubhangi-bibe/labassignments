package com.capgemini.lab9.lambdaExpressions;

import java.util.Scanner;
import java.util.stream.Stream;

public class Exercise2Tester {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the string");
		String str1 = sc.nextLine();
		Exercise2 ex = (str)->{String[] array =str.split("");
		String space ="";
		for(String s : array)
		{
			space +=s+"";
		}
		return space;
		};
		System.out.println(ex.addSpace(str1));
	}

}


/*
 * List<String> words = Arrays.asList(�Hello�,�Stream�,�Learning�);
 * words.stream().map(str->str.length()).forEach(System.out : : println);
 * 
 */