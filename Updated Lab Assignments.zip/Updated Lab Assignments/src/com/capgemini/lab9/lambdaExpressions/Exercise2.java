package com.capgemini.lab9.lambdaExpressions;

@FunctionalInterface
public interface Exercise2 {
  public abstract String addSpace(String str);
  
}
