package com.capgemini.lab3.assignments;

import java.util.Arrays;
import java.util.Scanner;

public class Exercise8 {
	static boolean isAlphabaticOrder(String s)  
    {  
        int n = s.length();  
        char array[] = new char [n];  
        for (int i = 0; i < n; i++) {  
            array[i] = s.charAt(i);  
        }  
        Arrays.sort(array);  
        for (int i = 0; i < n; i++)  
            if (array[i] != s.charAt(i))   
                return false;  
                
        return true;      
    }  
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in); 
		System.out.print("Enter a string: ");  
		String s= sc.nextLine(); 
        if (isAlphabaticOrder(s))  
            System.out.println("True");  
         else
             System.out.println("false");  
             
	}

}