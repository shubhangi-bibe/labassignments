package com.capgemini.lab3.assignments;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Scanner;

public class Exercise5 {
	private static Scanner sc=new Scanner(System.in);
	public static void main(String args[])throws IOException
    {
                char ch;
                int newLine=1,newWord=0;           
                Scanner scr=new Scanner(System.in);
                System.out.print("\nEnter File name: ");
                String str=scr.nextLine();
                FileInputStream f=new FileInputStream(str);
                int n=f.available();
                for(int i=0;i<n;i++)
                {
                            ch=(char)f.read();
                            if(ch=='\n')
                            newLine++;
                            else if(ch==' ')
                                        newWord++;
                                                               
                }
                System.out.println("\nNumber of lines : "+newLine);
                System.out.println("\nNumber of words : "+(newLine+newWord));
                System.out.println("\nNumber of characters : "+n);
               

    }
}
