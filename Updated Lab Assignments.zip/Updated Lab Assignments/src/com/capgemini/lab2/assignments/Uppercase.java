package com.capgemini.lab2.assignments;

import java.util.*;
public class Uppercase {

public static void main(String[] args) {
     Scanner sc=new Scanner(System.in);
     String str[];
     int count=0;
     System.out.println("Enter the String : ");
     String s=sc.nextLine();
     s=s+" ";
     
     for(int i=0;i<s.length();i++) {
    if(s.charAt(i)==' ') {
    count++;
    }
   
     }
     
     
     str=new String[count];
     String temp="";
     int n=0;
     for(int i=0;i<s.length();i++) {
   
    if(s.charAt(i)!=' ') {
    temp=temp+s.charAt(i);
     
   
    }
    else
    {
    str[n]=temp;
    n++;
    temp="";
    }
   
    }
     Arrays.sort(str);
     if(count%2==0) {
    for(int i=0;i<str.length/2;i++) {
    str[i]= str[i].toUpperCase();
    }
     }
     else {
    for(int i=0;i<(str.length/2)+1;i++) {
        str[i]=str[i].toUpperCase();
        }
     }
     for(int i=0;i<str.length;i++) {
    System.out.print(str[i]+" ");
     }
     
}


}

