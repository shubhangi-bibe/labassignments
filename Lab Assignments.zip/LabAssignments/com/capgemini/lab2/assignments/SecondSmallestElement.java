package com.capgemini.lab2.assignments;

import java.util.Scanner;

public class SecondSmallestElement {
static SecondSmallestElement sse = new SecondSmallestElement();
	public int secondSmallestInteger(int a[], int n)
	{
		int temp;
		for(int i =0; i<n;i++)
		{
			for(int j=i+1;j<n;j++)
			{
				if(a[i]>a[j])
				{
					temp=a[i];
					a[i]=a[j];
					a[j]=temp;
				}
			}
		}
		
		return a[1];
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc = new Scanner(System.in);
System.out.println("Enter number of elements");
int number = sc.nextInt();
int array[] = new int[number];
System.out.println("Enter the elements");
for(int i=0;i<number;i++)
{
  array[i] =sc.nextInt() ;	
}
int num = sse.secondSmallestInteger(array, number);
System.out.println(num);

	}

}
