package com.capgemini.lab1.assignments;

import java.util.Scanner;

public class CalculateSum {
static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) {
		// TODO Auto-generated method stub
System.out.println("Enter the number");
int n = sc.nextInt();
long sum = calculateSum(n);
System.out.println("Sum is "+sum);
	}
	
	public static int calculateSum(int num)
	{
		int sum=0;
		for(int i=1;i<=num;i++)
		{
			if(i%3==0 || i%5==0)
			{
				sum=sum+i;
			}
		}
		return sum;
		
	}

}
