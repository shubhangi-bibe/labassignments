package com.capgemini.lab1.assignments;

import java.util.Scanner;

public class PrimeNumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the number");
		int number = scanner.nextInt();
		int flag;
		for(int i=2;i<number;i++)
		{
			flag=0;
			for(int j=2;j<i;j++)
			{
				if(i%j==0)
				{
					flag=1;
				}
				
			}
			if(flag==0)
			{
				System.out.println(i);
			}
		}
	}

}
