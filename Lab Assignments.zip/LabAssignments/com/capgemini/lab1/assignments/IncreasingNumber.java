package com.capgemini.lab1.assignments;

import java.util.Scanner;

public class IncreasingNumber {
static IncreasingNumber number = new IncreasingNumber();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Scanner sc = new Scanner(System.in);
     System.out.println("Enter the number");
     int num = sc.nextInt();
     Boolean flag1 = number.isNumberIncreasing(num);
     if(flag1)
    	 System.out.println("The number is in increasing order");
     else
    	 System.out.println("The number is not in increasing order");
     
	}
 public Boolean isNumberIncreasing(int num)
 {
	boolean flag = false;
	 int currentDigit=num%10;
	 while(num>0)
	 {
		 if(currentDigit<=num%10)
		 {
			 flag=true;
			 
			 break;
		 }
	currentDigit = num%10;
		 num = num/10;
	 }
	 
	 return flag;
 }
}
