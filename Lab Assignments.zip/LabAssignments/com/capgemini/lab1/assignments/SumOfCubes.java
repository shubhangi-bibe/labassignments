package com.capgemini.lab1.assignments;

import java.util.Scanner;

public class SumOfCubes {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc = new Scanner(System.in);
System.out.println("Enter the number");
int number = sc.nextInt();
int totalSum = calculateSumOfCubes(number);
System.out.println("Sum of cubes of digits is: "+totalSum);
	}

	public static int calculateSumOfCubes(int num)
	{
		int sum=0;
		while(num!=0)
		{
		int n=num%10;
		sum=sum+(n*n*n);
		num=num/10;
		}
		return sum;
		
		
	}
}
