package com.capgemini.lab1.assignments;


import java.util.Scanner;

public class TrafficLight {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int choice;
do {
	System.out.println("Enter the light color: ");
	System.out.println("1.red\n2.yellow\n3.green");
	choice=sc.nextInt();
	switch(choice)
	{
	case 1: System.out.println("Stop");
	        break;
	case 2: System.out.println("Ready");
	        break;
	case 3: System.out.println("Go");
	        break;
	default: System.out.println("Invalid choice");
	}
	
}while(choice<=3);
	}

}
