package com.capgemini.lab1.assignments;

import java.util.Scanner;

public class CalculateDifference {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       Scanner scanner = new Scanner(System.in);
       System.out.println("Enter the number");
       int n = scanner.nextInt();
       int sumOfSquare=0;
       int squareOfSum=0, sum=0;
       int difference=0;
     // Find sum of squares   
       for(int i=1;i<=n;i++)
       {
    	   sumOfSquare = sumOfSquare+i*i;
       }
       System.out.println("Sum of Squares is"+sumOfSquare);
       
       // Find square of sum
       
       for(int i=1;i<n;i++)
       {
    	   sum = sum+i;
       }
       System.out.println("Sum of the numbers"+sum);
       squareOfSum = sum * sum;
       System.out.println("Square of sum is: "+squareOfSum);
       
       //Find the difference between sum of squares and square of sum
       
       int difference1 = calculateDifference(sumOfSquare,squareOfSum);
       System.out.println("The difference between sum of squares and square of sum is "+difference1);
	}
 public static int calculateDifference(int sumOfSquare, int squareOfSum)
 {
	 int difference = sumOfSquare - squareOfSum;
	return difference;
	 
 }
}
