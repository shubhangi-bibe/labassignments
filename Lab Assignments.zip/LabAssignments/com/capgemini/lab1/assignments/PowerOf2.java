package com.capgemini.lab1.assignments;

import java.util.Scanner;

public class PowerOf2 {
 static PowerOf2 power = new PowerOf2();
	public static void main(String[] args) {
    Scanner scanner = new Scanner(System.in);
    System.out.println("Enter the number");
    int n = scanner.nextInt();
   Boolean result = power.isPowerOfTwo(n);
   System.out.println(result);
 
	}
	
	boolean isPowerOfTwo(int n) 
	{ 
	    if (n == 0) 
	        return false; 
	    while (n != 1) 
	    { 
	        if (n%2 != 0) 
	            return false; 
	        n = n/2; 
	    } 
	    return true; 
	} 

}
