package com.capgemini.lab4.assignment.no1;

public abstract class Account {

	private long accNum;
	protected double balance;
	private String accHolder;
	static int autogen;

	static {
		autogen = 101;
	}

	
	

	public Account(String holder, double balance) {
		this.accHolder=holder;
		this.accNum = autogen++;
		this.balance = balance;
	}

	public double getBalance() {
		return balance;
	}

	public void deposit(double amount) {
		balance += amount;
	}

	public abstract void withdraw(double amount);
		/*
		 * if(amount>(balance-500)) { System.out.println("Insufficient balance"); } else
		 * { balance-=amount; }
		 * 
		 * if(amount<=(balance-500)) balance=amount; else
		 * System.out.println("Insufficint balance'");
		 */

	

	
	  public void display() { System.out.println("Account No:"+accNum);
	  System.out.println("Balance:"+balance);
	  System.out.println("Account Hoder Name:"+accHolder); }
	 
}
