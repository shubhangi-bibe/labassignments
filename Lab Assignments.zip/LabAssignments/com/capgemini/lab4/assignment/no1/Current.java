package com.capgemini.lab4.assignment.no1;

public class Current extends Account {

	private double overdraft;
	private static final double overdraft_limit = 10000;

	public Current(String holder, double balance) {
		super(holder, balance);
		// TODO Auto-generated constructor stub
		this.overdraft = overdraft_limit;
	}

	public boolean Check() {
		if (overdraft == overdraft_limit)
			return true;
		else
			return false;

	}

	public void check1()
	{
		if(Check()==true)
			System.out.println("True");
		else
			System.out.println("False");
			
	}

	@Override
	public void display() {
		// TODO Auto-generated method stub
		super.display();
		System.out.println("Overdraft:" + overdraft);
		check1();
	}

	@Override
	public void withdraw(double amount) {

		if (amount <= (balance + overdraft)) {
			balance -= amount;
			if (balance < 0) {
				overdraft += balance;
				balance = 0;
			}
		} else {
			System.out.println("Insufficient balance");
		}

	}
}
