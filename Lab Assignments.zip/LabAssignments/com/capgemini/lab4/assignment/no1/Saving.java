package com.capgemini.lab4.assignment.no1;

public class Saving extends Account {
	//private int min_bal;
	//private int init_bal;
	private static final int Min_Sav_bal=1000;
	

	public Saving(String holder) {
		super(holder, Min_Sav_bal);
		
	}

	@Override
	public void withdraw(double amount) {
		// TODO Auto-generated method stub
		
		if(Min_Sav_bal>(balance-amount))
		{
			System.out.println("Insufficient balance");
			
		}
		else 
		{
			balance -= amount;
			
		}
	}
	
}
