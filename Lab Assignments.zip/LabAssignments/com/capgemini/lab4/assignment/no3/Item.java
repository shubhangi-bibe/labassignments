package com.capgemini.lab4.assignment.no3;

public class Item {

	
	private int idNumber;
	private String title;
	private int numOfCopies;
	
	public Item(int idNumber, String title, int numOfCopies){
		this.idNumber = idNumber;
		this.title = title;
		this.numOfCopies = numOfCopies;
	}
	
	
	public int getIdNumber() {
		return idNumber;
	}


	public void setIdNumber(int idNumber) {
		this.idNumber = idNumber;
	}


	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public int getNumOfCopies() {
		return numOfCopies;
	}


	public void setNumOfCopies(int numOfCopies) {
		this.numOfCopies = numOfCopies;
	}


	public void checkIn() {
		numOfCopies = numOfCopies + 1;
	}
	
	public void checkOut() {
		numOfCopies = numOfCopies - 1;
	}
	
	@Override
	public String toString(){
		return "ID: " + idNumber + " Title: " + title + " Number of Copies: " + numOfCopies;
	}
	
	public void print() {
		System.out.println("ID: " + idNumber);
		System.out.println("Title: " + title);
		System.out.println("Number of copies: " + numOfCopies);
	}
	
	@Override
	public boolean equals(Object obj){
		if(obj == null)
			return false;
		
		Item otherItem = (Item) obj;
		return idNumber == otherItem.idNumber && 
			   title == otherItem.title && 
			   numOfCopies == otherItem.numOfCopies;
	}
	
	public void addItem(int idNumber, String title, int n) {
		setIdNumber(idNumber);
		setTitle(title);
		setNumOfCopies(n);
	}

}
