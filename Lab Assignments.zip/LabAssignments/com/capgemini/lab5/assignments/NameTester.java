package com.capgemini.lab5.assignments;

import java.util.Scanner;


public class NameTester {

	private static Scanner scanner=new Scanner(System.in);
	
	public static void main(String[] args) {
		try {
			
		System.out.println("Enter first name");
		String firstName=scanner.nextLine();
		System.out.println("Enter last name");
		String lastName=scanner.nextLine();
		
		if(firstName.equals("") || lastName.equals("")) {
		  throw new NameException("First name and last name can not be blank");
		}else {
			System.out.println(firstName+" "+lastName);
		}
		}catch(NameException e){
			e.printStackTrace();
			System.out.println("First name and last name can not be blank");
		}
		
	}

}
